remove(list = ls())

library(readxl)
library(KFAS)
library(ggplot2)
library(dplyr)
library(tidyr)
library(gridExtra)
library(patchwork)
library(urca)

dataLR = read_excel("LogRangeDes.xlsx",sheet = "data")

LogRange <- ts(dataLR[,2:69],frequency=12,start=c(1931,1))
LogRange=scale(LogRange)

Zt_orig= data.frame(read_excel("LogRangeDes.xlsx",sheet = "loadings", range = "B1:E69", col_names = TRUE))
Zt=Zt_orig[,1:4]
Zt=apply(Zt,2,as.numeric)
Zt_rest=Zt

FactPCA= data.frame(read_excel("LogRangeDes.xlsx",sheet = "factors", range = "B1:E1081", col_names = TRUE))

a_init=c(apply(FactPCA[1:12,1:4],2,mean))

Qt=diag(c(var(diff(FactPCA[,1])),apply(FactPCA[,2:4],2,var)))

phiR1=ar(FactPCA[,2],order.max=1)$par[,,1]
phiR2=ar(FactPCA[,3],order.max=1)$par[,,1]
phiR3=ar(FactPCA[,4],order.max=1)$par[,,1]

Tt=diag(c(1,phiR1,phiR2,phiR3))

Rt <- diag(4)

Residuals<-LogRange-t(data.matrix(Zt_orig)%*%t(data.matrix(FactPCA)))
Ht<-diag(apply(Residuals,2,var))

###################

# Initial guess for factor evolution covariance matrix
# Initial guess for measurement error covariance matrix

Tsample<-length(FactPCA[,1])
# EM algorithm
max_iter <- 100
tolerance <- 1e-4
prev_loglik <- -100000

match_zeros <- function(A, B) {
  for (i in 1:nrow(A)) {
    for (j in 1:ncol(A)) {
      if (A[i, j] == 0) {
        B[i, j] <- 0
      }
    }
  }
  return(B)
}

for (iter in 1:max_iter) {
  # E-step: Run Kalman filter and smoother with current parameters
  
  model <- SSModel(LogRange ~-1+SSMcustom(Z = Zt, T = Tt, R = Rt, Q = Qt, a1=a_init,P1=Qt), 
                   data=LogRange, H = Ht)
  
  filtered <- KFS(model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))
  
  phiR1=ar(filtered$alphahat[,2],order.max=1)$par[,,1]
  phiR2=ar(filtered$alphahat[,3],order.max=1)$par[,,1]
  phiR3=ar(filtered$alphahat[,4],order.max=1)$par[,,1]
 
  Tt=diag(c(1,phiR1,phiR2,phiR3))

  # M-step: Update parameters using smoothed state estimates
  
  loading_update <-t(LogRange) %*% filtered$alphahat %*% solve(t(filtered$alphahat) %*% filtered$alphahat)
  
  Zt<-t(match_zeros(t(Zt_rest), t(loading_update)))
  Zt=apply(Zt,2,as.numeric)
  
  Qt<-filtered$V_eta[,,1080]
  a1=apply(filtered$a[1:24,],2,mean)
  
  Ht<-diag(apply(filtered$epshat,2,var))

  #####  Convergence
  
  # Compute log-likelihood
  loglik <- filtered$logLik
  
  # Check for convergence
  delta_loglik <- abs(loglik - prev_loglik)
  avg_loglik = (abs(loglik) + abs(prev_loglik) + 2.2204e-16)/2
  if ((delta_loglik/avg_loglik) < tolerance){ break }

  # Update previous log-likelihood
  prev_loglik <- loglik
  print(iter)
}


##############################
##### Final estimates ########
##############################

(Ht)
(Qt)
(Tt)

level.Global <- c(filtered$alphahat[1080,1],filtered$V[1,1,1080])
level.R1<-c(filtered$alphahat[1080,2],filtered$V[2,2,1080])
level.R2<-c(filtered$alphahat[1080,3],filtered$V[3,3,1080])
level.R3<-c(-1*filtered$alphahat[1080,4],filtered$V[4,4,1080])

matrix(c(level.Global,level.R1,level.R2,level.R3),2,4)

### FACTORS ###

### ESCALAMIENTO FACTORES ###

FactorsMean <- matrix(0,4,1)
FactorsSd <- matrix(0,4,1)
ScaledFactors <- matrix(0,1080,4)
LoadingFactors<- matrix(0,68,4)
MSE.Factors <- matrix(0,1080,4)
levsup25.Factors <- matrix(0,1080,4)
levinf25.Factors <- matrix(0,1080,4)
levsup50.Factors <- matrix(0,1080,4)
levinf50.Factors <- matrix(0,1080,4)
levsup75.Factors <- matrix(0,1080,4)
levinf75.Factors <- matrix(0,1080,4)
levsup95.Factors <- matrix(0,1080,4)
levinf95.Factors <- matrix(0,1080,4)
levsup99.Factors <- matrix(0,1080,4)
levinf99.Factors <- matrix(0,1080,4)

for (i in 1:3) {
  FactorsMean[i] <- mean(filtered$alphahat[,i])
  FactorsSd[i] <- sd(filtered$alphahat[,i])
  ScaledFactors[,i] <- (filtered$alphahat[,i] - FactorsMean[i]) / FactorsSd[i]
  LoadingFactors[,i]<- (Zt[,i]*FactorsSd[i])+FactorsMean[i] 
  
  MSE.Factors<-filtered$V[i,i,1:1080]
  
  levsup25.Factors[,i]<-ScaledFactors[,i]+qnorm(0.625,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])  
  levinf25.Factors[,i]<-ScaledFactors[,i]-qnorm(0.625,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])
  
  levsup50.Factors[,i]<-ScaledFactors[,i]+qnorm(0.75,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])  
  levinf50.Factors[,i]<-ScaledFactors[,i]-qnorm(0.75,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])
  
  levsup75.Factors[,i]<-ScaledFactors[,i]+qnorm(0.875,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])  
  levinf75.Factors[,i]<-ScaledFactors[,i]-qnorm(0.875,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])
  
  levsup95.Factors[,i]<-ScaledFactors[,i]+qnorm(0.975,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])  
  levinf95.Factors[,i]<-ScaledFactors[,i]-qnorm(0.975,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])
  
  levsup99.Factors[,i]<-ScaledFactors[,i]+qnorm(0.995,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])  
  levinf99.Factors[,i]<-ScaledFactors[,i]-qnorm(0.995,0,1,lower.tail = TRUE)*sqrt(filtered$V[i,i,1:1080])
}

### IDENTIFICATION REGIONAL FACTOR 3 ####

R3identification=(-1)*(filtered$alphahat[,4])

  FactorsMean[4] <- mean(R3identification)
  FactorsSd[4] <- sd(R3identification)
  ScaledFactors[,4] <- (R3identification - FactorsMean[4]) / FactorsSd[4]
  LoadingFactors[,4]<- (-1)*(Zt[,4]*FactorsSd[4])+FactorsMean[4] 
  
  MSE.Factors<-filtered$V[4,4,1:1080]
  
  levsup25.Factors[,4]<-ScaledFactors[,4]+qnorm(0.625,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])  
  levinf25.Factors[,4]<-ScaledFactors[,4]-qnorm(0.625,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])
  
  levsup50.Factors[,4]<-ScaledFactors[,4]+qnorm(0.75,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])  
  levinf50.Factors[,4]<-ScaledFactors[,4]-qnorm(0.75,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])
  
  levsup75.Factors[,4]<-ScaledFactors[,4]+qnorm(0.875,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])  
  levinf75.Factors[,4]<-ScaledFactors[,4]-qnorm(0.875,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])
  
  levsup95.Factors[,4]<-ScaledFactors[,4]+qnorm(0.975,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])  
  levinf95.Factors[,4]<-ScaledFactors[,4]-qnorm(0.975,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])
  
  levsup99.Factors[,4]<-ScaledFactors[,4]+qnorm(0.995,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])  
  levinf99.Factors[,4]<-ScaledFactors[,4]-qnorm(0.995,0,1,lower.tail = TRUE)*sqrt(filtered$V[4,4,1:1080])


  ScaledFactors <- ts(ScaledFactors, frequency = 12, start = c(1931, 1))
ScaledLoading <-match_zeros(Zt_rest, LoadingFactors)


##################################################
#### FIGURES ####
##################################################

### FACTORS ####
T <- nrow(LogRange)
dates <- seq(from = as.Date("1931-01-01"), by = "month", length.out = T)

df_center <- as.data.frame(LogRange)
df_center$Date <- dates

df_long <- df_center %>%
  pivot_longer(cols = -Date, names_to = "Series", values_to = "Value")

df_factor <- data.frame(
  Date = dates,
  Value = ScaledFactors[, 1]
)

p <- ggplot() +
  geom_line(data = df_long, aes(x = Date, y = Value, group = Series),
            color = "lightblue", size = 0.7, alpha = 0.7) +
  geom_line(data = df_factor, aes(x = Date, y = Value),
            color = "black", size = 0.7) +
  scale_y_continuous(limits = c(-3, 3)) +
  scale_x_date(date_breaks = "5 years", date_labels = "%Y") +
  labs(
    x = "Year",
    y = "Standardized centre temperature"
  ) +
  theme_minimal() +
  theme(
    #  axis.title = element_blank(),
    axis.text.x = element_text(angle = 90, hjust = 1),
    panel.grid.minor = element_blank(),
    plot.background = element_rect(fill = "white", color = NA)
  )

ggsave("GlobFact_Range.png", p, width = 6, height = 4, dpi = 300)

# SCALED REGIONAL FACTORS ##
nombres_series <- c("Region 1", "Region 2", "Region 3")
colores_series <- c("black", "black", "black")

graficos <- list()
for (i in 1:3) {
  serie <- ScaledFactors[, 1 + i] 
  data <- data.frame(fecha = seq(as.Date("1931-01-01"), 
          by = "1 month", length.out = length(serie)), y = serie)
  graficos[[i]] <- ggplot(data, aes(x = fecha, y = y)) +
    geom_line(color = colores_series[i]) +
    labs(title = nombres_series[i],
         x = "",
         y = "") +
    theme_minimal()+
    coord_cartesian(ylim = c(-5, 5))+
    theme(plot.title = element_text(size = 10)) 
}

grid.arrange(grobs = graficos, ncol = 1)


###LOADINGS###########

cities <- colnames(dataLR)
df <- data.frame(
  Observacion = 1:68, 
  Valor = ScaledLoading[, 1],
  Ciudad = cities[2:69]
)

p <- ggplot(data = df, aes(x = Observacion, y = Valor)) +
  geom_bar(stat = "identity", fill = "gray", width = 0.85) +  # Wider bars 
  geom_text(aes(label = Ciudad, y = 0), 
            hjust = 0, vjust = 0.5, 
            size = 2, angle = 90) +     # <-- Increased font size here
  labs(title = NULL, x = "Cities", y = "Global loadings") +
  theme_minimal() +
  theme(
    axis.text.x = element_blank(),
    panel.background = element_rect(fill = "white", color = NA),
    plot.background = element_rect(fill = "white", color = NA)
  )

ggsave("GlobLoadings_Range.png", plot = p, 
       width = 6, height = 4, units = "in", dpi = 300, bg = "white")

#####################

non_zero_R1 <- which(ScaledLoading[, 2] != 0)
non_zero_R2 <- which(ScaledLoading[, 3] != 0)
non_zero_R3 <- which(ScaledLoading[, 4] != 0)

LoaR1 <- cbind(ScaledLoading[non_zero_R1, 1],ScaledLoading[non_zero_R1, 2])
LoaR2 <- cbind(ScaledLoading[non_zero_R2, 1],ScaledLoading[non_zero_R2, 3])
LoaR3 <- cbind(ScaledLoading[non_zero_R3, 1],ScaledLoading[non_zero_R3, 4])

generar_grafico <- function(Z, Z2, cities, titulo,NumReg) {
  df <- data.frame(Observacion = 1:NumReg, Valor = Z, Ciudad = cities)
  df2 <- data.frame(Observacion = 1:NumReg, Valor = Z2, Ciudad = cities)
  
  ggplot(data = df, aes(x = Observacion, y = Valor)) +
    geom_bar(data = df2, aes(x = Observacion, y = Valor,fill=cities), stat = "identity", fill = "red", position = "stack") +
    geom_bar(data = df, aes(x = Observacion, y = Valor,fill=cities), stat = "identity", fill = "skyblue", position = "stack") +
    geom_text(data = df, aes(label = Ciudad, y = 0), hjust = 0, vjust = 0.5, size = 3, angle = 90) + 
    geom_hline(yintercept = 0, color = "black") +  # L?nea en el eje x
    labs(title = titulo, x = NULL, y = NULL) +  # T?tulo personalizado
    theme_minimal() +
    theme(axis.text.x = element_blank(),
          plot.title = element_text(size = 8)) +  # Tama?o del t?tulo
    coord_cartesian(ylim = c(-0.1, 2))  # Establecer l?mites del eje y
}

titulos <- paste("Region", 1:3)
graR1 <- generar_grafico(LoaR1[,2], LoaR1[,1], cities[non_zero_R1+1], titulos[1],length(LoaR1[,1]))
graR2 <- generar_grafico(LoaR2[,2], LoaR2[,1], cities[non_zero_R2+1], titulos[2],length(LoaR2[,1]))
graR3 <- generar_grafico(LoaR3[,2], LoaR3[,1], cities[non_zero_R3+1], titulos[3],length(LoaR3[,1]))

combined_figure <- graR1 / graR2 / graR3 
print(combined_figure)


### NEW STACKED FIGURE ###

generar_grafico <- function(vector1, vector2, categories, titulo, NumBlock) {
  
  IndCity   <- rep(categories, 2)
  IndFactor <- c(rep("Global", NumBlock), rep("Regional", NumBlock))
  value     <- c(vector1, vector2)
  
  data <- data.frame(IndCity, IndFactor, value)
  
  data$IndFactor <- factor(data$IndFactor, levels = c("Global", "Regional"))
  
  ggplot(data, aes(x = IndCity, y = value, fill = IndFactor)) +
    geom_bar(position = "stack", stat = "identity") +
    geom_text(aes(label = IndCity, y = 0),
              hjust = 0, vjust = 0.5, size = 2.7, angle = 90) +
    geom_text(aes(label = round(value, 2), color = IndFactor),
              position = position_stack(vjust = 0.9),
              size = 2) +
    geom_hline(yintercept = 0, color = "black") +
    labs(title = titulo, x = NULL, y = NULL) +
    scale_fill_manual(values = c(Global = "black", Regional = "grey75")) +
    scale_color_manual(values = c(Global = "white", Regional = "black")) +
    theme_minimal() +
    theme(axis.text.x = element_blank(),
          plot.title = element_text(size = 8)) +
    coord_cartesian(ylim = c(-0.1, 1.5)) +
    guides(fill = "none", color = "none")
}


titulos <- paste("Region", 1:3)
graR1 <- generar_grafico(LoaR1[,2], LoaR1[,1], cities[non_zero_R1+1], titulos[1],length(LoaR1[,1]))
graR2 <- generar_grafico(LoaR2[,2], LoaR2[,1], cities[non_zero_R2+1], titulos[2],length(LoaR2[,1]))
graR3 <- generar_grafico(LoaR3[,2], LoaR3[,1], cities[non_zero_R3+1], titulos[3],length(LoaR3[,1]))

combined_figure <- graR1 / graR2 / graR3 
print(combined_figure)


##################################################
####### UNIT ROOT TESTING #######
##################################################

run_tests <- function(series) {
  # Helper function to assign p-value bracket
  assign_pval_bracket <- function(stat, crit_vals) {
    if (is.null(crit_vals) || any(is.na(crit_vals))) return(NA)
    if (stat < crit_vals[1]) return("< 0.01")
    else if (stat < crit_vals[2]) return("< 0.05")
    else if (stat < crit_vals[3]) return("< 0.10")
    else return(">= 0.10")
  }
  
  # ADF
  adf_test <- ur.df(series, type = "none", selectlags = "AIC")
  adf_stat <- adf_test@teststat[1]
  adf_pval <- assign_pval_bracket(adf_stat, adf_test@cval[1,])
  
  # PP
  pp_test <- ur.pp(series, type = "Z-tau", model = "constant", lags = "short")
  pp_stat <- pp_test@teststat
  pp_pval <- assign_pval_bracket(pp_stat, pp_test@cval[1,])
  
  # KPSS (note: H0 is stationarity)
  kpss_test <- ur.kpss(series, type = "mu", lags = "short")
  kpss_stat <- kpss_test@teststat
  # For KPSS, we reverse the logic: if stat > critical value → reject stationarity
  kpss_crit <- kpss_test@cval
  kpss_pval <- if (kpss_stat > kpss_crit[4]) {
    ">= 0.01"
  } else if (kpss_stat > kpss_crit[3]) {
    "< 0.01"
  } else if (kpss_stat > kpss_crit[2]) {
    "< 0.025"
  } else if (kpss_stat > kpss_crit[1]) {
    "< 0.05"
  } else {
    "< 0.10"
  }
  
  # ERS
  ers_test <- ur.ers(series, type = "DF-GLS", model = "constant", lag.max = 4)
  ers_stat <- ers_test@teststat
  ers_pval <- assign_pval_bracket(ers_stat, ers_test@cval[1,])
  
  return(c(
    ADF_stat = adf_stat, ADF_p = adf_pval,
    PP_stat = pp_stat, PP_p = pp_pval,
    KPSS_stat = kpss_stat, KPSS_p = kpss_pval,
    ERS_stat = ers_stat, ERS_p = ers_pval
  ))
}

series_list <- as.data.frame(ScaledFactors[, 1:4])
results <- lapply(series_list, run_tests)
results_df <- do.call(rbind, results)
results_df <- tibble::rownames_to_column(as.data.frame(results_df), var = "Variable")
print(results_df,digits=2)


### FIGURE IN APPENDIX 
png("ACF_PACF_Factors_LR.png", width = 1600, height = 2400, res = 200)
cols <- c(1, 2, 3, 4)
titles <- c("Global", "Region 1", "Region 2", "Region 3")

par(mfrow = c(4, 2), mar = c(3, 3, 3, 1))  # Adjust margins

for (i in seq_along(cols)) {
  col_index <- cols[i]
  data_series <- ScaledFactors[, col_index]
  
  acf_obj <- acf(data_series, lag.max = 120, plot = FALSE)
  pacf_obj <- pacf(data_series, lag.max = 120, plot = FALSE)
  
  plot(acf_obj, main = paste("ACF -", titles[i]), ylim = c(-0.1, 0.3))
  
  plot(pacf_obj, main = paste("PACF -", titles[i]), ylim = c(-0.1, 0.3))
}

dev.off()


# GLOBAL FACTOR 

LogRange<- ScaledFactors[,1]

STM <- SSModel(LogRange ~ SSMtrend(degree = 2, Q = list(NA, NA)),
               data = LogRange, H = NA)

SfitSTM <- fitSSM(STM, inits = log(c(var(LogRange), 0.01, 0.01)), method = "BFGS")

SmoothSTM <- KFS(SfitSTM$model, smoothing = c("state", "mean"))

smoothed_signal <- SmoothSTM$muhat  # smoothed observation (Z_t * alpha_t)
smoothed_level <- SmoothSTM$alphahat[, 1]  # smoothed level
smoothed_slope <- SmoothSTM$alphahat[, 2]  # smoothed slope

plot(LogRange, type = 'l', col = 'gray', main = 'Smoothed vs Original')
lines(smoothed_signal, col = 'blue', lwd = 2)
lines(smoothed_level, col = 'red', lwd = 2, lty = 2)  # optional
legend("topleft", legend = c("Original", "Smoothed signal", "Smoothed level"),
       col = c("gray", "blue", "red"), lty = c(1, 1, 2), lwd =0.5)

df_smooth <- data.frame(
  Date = df_factor$Date,  # o usa directamente tu vector de fechas
  Value = smoothed_signal
)

p <- ggplot() +
  geom_line(data = df_long, aes(x = Date, y = Value, group = Series),
            color = "lightblue", size = 0.7, alpha = 0.7) +
  geom_line(data = df_factor, aes(x = Date, y = Value),
            color = "black", size = 0.7) +
  geom_line(data = df_smooth, aes(x = Date, y = Value),
            color = "red", size = 0.7, linetype = "dashed") +  # Línea roja punteada
  scale_y_continuous(limits = c(-3, 3)) +
  scale_x_date(date_breaks = "5 years", date_labels = "%Y") +
  labs(
    x = "Year",
    y = "Standardized centre temperature"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 90, hjust = 1),
    panel.grid.minor = element_blank(),
    plot.background = element_rect(fill = "white", color = NA)
  )


ggsave("GlobFact_Range2.png", p, width = 6, height = 4, dpi = 300)


# CITY COMPONENTS

cities <- colnames(dataLR)
which(cities=="Madrid")

LoadingMadrid=ScaledLoading[which(cities=="Madrid")-1,]
LoadingBarcelona=ScaledLoading[which(cities=="Barcelona")-1,]
LoadingSevilla=ScaledLoading[which(cities=="Sevilla")-1,]
LoadingCoruna=ScaledLoading[which(cities=="Coruna")-1,]

MadridComp=ScaledFactors%*%LoadingMadrid
BarcelonaComp=ScaledFactors%*%LoadingBarcelona
SevillaComp=ScaledFactors%*%LoadingSevilla
CorunaComp=ScaledFactors%*%LoadingCoruna

T <- nrow(ScaledFactors)
fecha <- seq(as.Date("1931-01-01"), by = "1 month", length.out = T)

df_comp <- data.frame(
  fecha = fecha[840:1080],
  Madrid = as.vector(MadridComp[840:1080]),
  Barcelona = as.vector(BarcelonaComp[840:1080]),
  Sevilla = as.vector(SevillaComp[840:1080]),
  Coruna = as.vector(CorunaComp[840:1080])
)

df_long <- pivot_longer(df_comp, cols = -fecha, names_to = "Ciudad", 
                        values_to = "Componente")

p<-ggplot(df_long, aes(x = fecha, y = Componente)) + 
  geom_line(color = "black", size = 0.4) +  # <- Cambia aquí el color dentro de geom_line()
  facet_wrap(~ Ciudad, ncol = 1, scales = "fixed") +  # <- Cambia "free_y" por "fixed"
  scale_x_date(date_labels = "%Y", date_breaks = "5 years") +
  labs(title = "",
       x = "Year", y = "Log-Range temperatures") +
  theme_minimal(base_size = 8) +
  theme(legend.position = "none")

ggsave("CommonCompLR.png", p, width = 6, height = 4, dpi = 300)
