remove(list= ls())

library(readxl)
library(KFAS)


########################
dataMax <- read_excel("TempMaxSpain.xlsx",sheet = "data")
dataMin <- read_excel("TempMinSpain.xlsx",sheet = "data")

dataMax=ts(dataMax[349:1440,2:5],frequency=12,start=c(1930,1))
dataMin=ts(dataMin[349:1440,2:5],frequency=12,start=c(1930,1))

CentroTemp = (dataMax+dataMin)/2
colnames(CentroTemp) <- c("Madrid","Barcelona","Sevilla","A Coruna")
CentroTemp <- ts(CentroTemp,frequency=12,start=c(1930,1))

RankTemp = log(dataMax-dataMin)
colnames(RankTemp) <- c("Madrid","Barcelona","Sevilla","A Coruna")
RankTemp <- ts(RankTemp,frequency=12,start=c(1930,1))

Madrid <- ts(cbind(CentroTemp[,1],RankTemp[,1]),frequency=12,start=c(1930,1))
colnames(Madrid) <- c("Center","LogRange")

########################
##### KFS  #####
########################

modelC <-SSModel(Madrid[,1]~SSMtrend(degree=2,Q=list(matrix(NA),matrix(NA)),
                                  a1=c(14,0.65))+
                    SSMseasonal(period=12,sea.type='trigonometric',Q=matrix(NA)),
                  data=Madrid,H=matrix(NA))
  
  modelLR <-SSModel(Madrid[,2]~SSMtrend(degree=2,Q=list(matrix(NA),matrix(NA)),
                                       a1=c(2.4,0.036))+
                     SSMseasonal(period=12,sea.type='trigonometric',Q=matrix(NA)),
                   data=Madrid,H=matrix(NA))


fitC <-fitSSM(model=modelC,inits=c(3.8652, 0,0,0,0,
                                0,0,0,0,
                                 0,0,0,0,
                                 0),method='BFGS')

fitLR <-fitSSM(model=modelLR,inits=c(-3.0717, 0,0,0,0,
                                   0,0,0,0,
                                   0,0,0,0,
                                   0),method='BFGS')

outC <- KFS(fitC$model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))
outLR <- KFS(fitLR$model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))
initValC<-0
initValLR<-0
for (i in 1:13) {
  initValC[i]=mean(outC$a[2:13,i])
  initValLR[i]=mean(outLR$a[2:13,i])
}


Center=ts(Madrid[13:1092,1],frequency=12,start=c(1931,1))
LogRange=ts(Madrid[13:1092,2],frequency=12,start=c(1931,1))

modelC <-SSModel(Center~SSMtrend(degree=2,Q=list(matrix(NA),matrix(NA)),
                                a1=c(initValC[1:2]))+
                  SSMseasonal(period=12,sea.type='trigonometric',Q=matrix(NA),
                              a1=c(initValC[3:13])),
                data=Center,H=matrix(NA))

modelLR <-SSModel(LogRange~SSMtrend(degree=2,Q=list(matrix(NA),matrix(NA)),
                                 a1=c(initValLR[1:2]))+
                   SSMseasonal(period=12,sea.type='trigonometric',Q=matrix(NA),
                               a1=c(initValLR[3:13])),
                 data=LogRange,H=matrix(NA))

updatefn <- function(pars, model,estimate = TRUE){
  Q <- as.matrix(model$Q[, , 1])
  naQd <- which(is.na(diag(Q)))
  naQnd <- which(upper.tri(Q[naQd, naQd]) & is.na(Q[naQd, naQd]))
  Q[naQd, naQd][lower.tri(Q[naQd, naQd])] <- 0
  diag(Q)[naQd] <- exp(0.5 *c(pars[1:2],rep(pars[3],2),rep(pars[4],9)))
  
  Q[naQd, naQd][naQnd] <- rep(pars[5],length(naQnd))
  model$Q[naQd, naQd, 1] <- crossprod(Q[naQd, naQd])
  
  H <- as.matrix(model$H[, , 1])
  naHd <- which(is.na(diag(H)))
  naHnd <- which(upper.tri(H[naHd, naHd]) & is.na(H[naHd, naHd]))
  H[naHd, naHd][lower.tri(H[naHd, naHd])] <- 0
  diag(H)[naHd] <- exp(0.5 * pars[length(naQd) + length(naQnd) +
                                    1:length(naHd)])
  H[naHd, naHd][naHnd] <- pars[length(naQd) + length(naQnd) +
                                 length(naHd) + 1:length(naHnd)]
  model$H[naHd, naHd, 1] <- crossprod(H[naHd, naHd])
  if (estimate) {
    -logLik(model)
  } else {
    model
  }
  model
}

fitC <-fitSSM(model=modelC,inits=c(3.8652,0,0,0,0,
                                 0,0,0,0,
                                 0,0,0,0,
                                 0),updatefn,method='BFGS')

fitLR <-fitSSM(model=modelLR,inits=c(0, 0,0,0,0,
                                     0,0,0,0,
                                     0,0,0,0,
                                     0),updatefn,method='BFGS')

##############################
########## RESULTS ###########
##############################

(HmatrixC = fitC$model$H)
(QmatrixC = fitC$model$Q)

(HmatrixLR = fitLR$model$H)
(QmatrixLR = fitLR$model$Q)


outC <- KFS(fitC$model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))
level.Center <- outC$alphahat[,1]
slope.Center <- outC$alphahat[,2]
seas.Center <- rowSums(outC$alphahat[,3:13])
epshat.Center <- outC$epshat

outLR <- KFS(fitLR$model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))
level.LR <- outLR$alphahat[,1]
slope.LR <- outLR$alphahat[,2]
seas.LR <- rowSums(outLR$alphahat[,3:13])
epshat.LR <- outLR$epshat

level.Center[1080]
outC$V[1,1,1080]
slope.Center[1080]
outC$V[2,2,1080]

level.LR[1080]
outLR$V[1,1,1080]
slope.LR[1080]
outLR$V[2,2,1080]

########################################################
########################################################
#### Testing for univariate random walk plus noise model
########################################################
########################################################

# CENTER
#########
STM <-SSModel(Center~SSMtrend(degree=2,Q=list(matrix(0),Q=QmatrixC[2,2,]))
              +
                SSMseasonal(period=12,sea.type='trigonometric',Q=matrix(NA)),
              data=Center,H=HmatrixC)

fitSTM <-fitSSM(model=STM,inits=c(0,
                                  0,0,0,0,
                                  0,0,0,0,
                                  0,0,0,0,
                                  0,0,0),method='BFGS')

outCTest <- KFS(fitSTM$model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))

ehat=outCTest$v[(outCTest$d+1):1080]/sqrt((outCTest$F[(outCTest$d+1):1080]))

EtaTest=(length(ehat)^(-2))*sum(cumsum(ehat)^2)/var(ehat)

#########
# LOG-RANGE
#########
STM <-SSModel(LogRange~SSMtrend(degree=2,Q=list(matrix(0),Q=QmatrixLR[2,2,]))
              +
                SSMseasonal(period=12,sea.type='trigonometric',Q=matrix(NA)),
              data=LogRange,H=HmatrixLR)

fitSTM <-fitSSM(model=STM,inits=c(0,
                                  0,0,0,0,
                                  0,0,0,0,
                                  0,0,0,0,
                                  0,0,0),method='BFGS')

outCTest <- KFS(fitSTM$model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))

ehat=outCTest$v[(outCTest$d+1):1080]/sqrt((outCTest$F[(outCTest$d+1):1080]))

EtaTest=(length(ehat)^(-2))*sum(cumsum(ehat)^2)/var(ehat)


########################################################
########################################################
#### Testing against a stochastic slope
########################################################
########################################################

# CENTER (SIGMA ETA=0)
ZetaTestC=(1/((length(ehat)^4)*var(ehat)))*sum(cumsum(cumsum(ehat))^2)*100

# LOG-RANGE (SIGMA ETA>0)
DLR <- diff(LogRange)
model <-SSModel(DLR~SSMtrend(degree=1,Q=list(matrix(NA)))+
                  SSMseasonal(period=12,sea.type='trigonometric',Q=matrix(NA)),
                data=DLR,H=matrix(NA))

fit <-fitSSM(model=model,inits=c(0,
                                 0,0,0,0,
                                 0,0,0,0,
                                 0,0,0,0,
                                 0,0,0),method='BFGS')

out <- KFS(fit$model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))

ehat=out$v[(out$d+1):1079]/sqrt((out$F[(out$d+1):1079]))

ZetaTestC=(1/((length(ehat)^4)*var(ehat)))*sum(cumsum(cumsum(ehat))^2)


##############################################################
##############################################################
### Testing for deterministic seasonal components in a FS-BSM
##############################################################
##############################################################

### CENTER

STM <-SSModel(Center~SSMtrend(degree=2,Q=list(matrix(0),matrix(NA)))
              + SSMseasonal(period=12,sea.type='trigonometric',Q=matrix(0)),
              data=Center,H=matrix(NA))

SfitSTM <-fitSSM(model=STM,inits=c(0,
                                   0,0,0,0,
                                   0,0,0,0,
                                   0,0,0,0,
                                   0,0,0),method='BFGS')

SoutCTest <- KFS(SfitSTM$model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))

Sehat=SoutCTest$v[(SoutCTest$d+1):1080]/sqrt((SoutCTest$F[(SoutCTest$d+1):1080]))

s2hat=var(Sehat)

a2=2
a1=1

p1_1<-0
p2_1<-0
p1_2<-0
p2_2<-0
p1_3<-0
p2_3<-0
p1_4<-0
p2_4<-0
p1_5<-0
p2_5<-0
p1_6<-0
p2_6<-0

for (i in 1:length(Sehat)) {
  p1_1[i]<-Sehat[i]*cos(((2*pi*1)/12)*i)  
  p2_1[i]<-Sehat[i]*sin(((2*pi*1)/12)*i)  
  
  p1_2[i]<-Sehat[i]*cos(((2*pi*2)/12)*i)  
  p2_2[i]<-Sehat[i]*sin(((2*pi*2)/12)*i)  
  
  p1_3[i]<-Sehat[i]*cos(((2*pi*3)/12)*i)  
  p2_3[i]<-Sehat[i]*sin(((2*pi*3)/12)*i)  
  
  p1_4[i]<-Sehat[i]*cos(((2*pi*4)/12)*i)  
  p2_4[i]<-Sehat[i]*sin(((2*pi*4)/12)*i)  
  
  p1_5[i]<-Sehat[i]*cos(((2*pi*5)/12)*i)  
  p2_5[i]<-Sehat[i]*sin(((2*pi*5)/12)*i)  
  
  p1_6[i]<-Sehat[i]*cos(((2*pi*6)/12)*i) 
  p2_6[i]<-Sehat[i]*sin(((2*pi*6)/12)*i) 
}

Sp_1=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_1)^2+cumsum(p2_1)^2)

Sp_2=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_2)^2+cumsum(p2_2)^2)

Sp_3=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_3)^2+cumsum(p2_3)^2)

Sp_4=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_4)^2+cumsum(p2_4)^2)

Sp_5=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_5)^2+cumsum(p2_5)^2)

Sp_6=a1*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_6)^2+cumsum(p2_6)^2)

rbind(Sp_1,Sp_2,Sp_3,Sp_4,Sp_5,Sp_6,sum(Sp_2,Sp_3,Sp_4,Sp_5,Sp_6),sum(Sp_1,Sp_2,Sp_3,Sp_4,Sp_5,Sp_6))

### LOG-RANGE

STM <-SSModel(LogRange~SSMtrend(degree=2,Q=list(matrix(NA),matrix(0)))
              + SSMseasonal(period=12,sea.type='trigonometric',Q=matrix(0)),
              data=LogRange,H=matrix(NA))

SfitSTM <-fitSSM(model=STM,inits=c(0,
                                   0,0,0,0,
                                   0,0,0,0,
                                   0,0,0,0,
                                   0,0,0),method='BFGS')

SoutCTest <- KFS(SfitSTM$model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))

Sehat=SoutCTest$v[(SoutCTest$d+1):1080]/sqrt((SoutCTest$F[(SoutCTest$d+1):1080]))

s2hat=var(Sehat)

a2=2
a1=1

p1_1<-0
p2_1<-0
p1_2<-0
p2_2<-0
p1_3<-0
p2_3<-0
p1_4<-0
p2_4<-0
p1_5<-0
p2_5<-0
p1_6<-0
p2_6<-0

for (i in 1:length(Sehat)) {
  p1_1[i]<-Sehat[i]*cos(((2*pi*1)/12)*i)  
  p2_1[i]<-Sehat[i]*sin(((2*pi*1)/12)*i)  
  
  p1_2[i]<-Sehat[i]*cos(((2*pi*2)/12)*i)  
  p2_2[i]<-Sehat[i]*sin(((2*pi*2)/12)*i)  
  
  p1_3[i]<-Sehat[i]*cos(((2*pi*3)/12)*i)  
  p2_3[i]<-Sehat[i]*sin(((2*pi*3)/12)*i)  
  
  p1_4[i]<-Sehat[i]*cos(((2*pi*4)/12)*i)  
  p2_4[i]<-Sehat[i]*sin(((2*pi*4)/12)*i)  
  
  p1_5[i]<-Sehat[i]*cos(((2*pi*5)/12)*i)  
  p2_5[i]<-Sehat[i]*sin(((2*pi*5)/12)*i)  
  
  p1_6[i]<-Sehat[i]*cos(((2*pi*6)/12)*i) 
  p2_6[i]<-Sehat[i]*sin(((2*pi*6)/12)*i) 
}

Sp_1=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_1)^2+cumsum(p2_1)^2)

Sp_2=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_2)^2+cumsum(p2_2)^2)

Sp_3=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_3)^2+cumsum(p2_3)^2)

Sp_4=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_4)^2+cumsum(p2_4)^2)

Sp_5=a2*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_5)^2+cumsum(p2_5)^2)

Sp_6=a1*(length(Sehat)^(-2))*(s2hat^(-1))*sum(cumsum(p1_6)^2+cumsum(p2_6)^2)

rbind(Sp_1,Sp_2,Sp_3,Sp_4,Sp_5,Sp_6,sum(Sp_2,Sp_3,Sp_4,Sp_5,Sp_6),sum(Sp_1,Sp_2,Sp_3,Sp_4,Sp_5,Sp_6))

########################
########################
# DIAGNOSTIC CHECKING  #
########################
########################

### FIGURE C ####

stdresC <- rstandard(outC)
stdresLR <- rstandard(outLR)

png("MadridDiagn_XX.png", width = 2400, height = 1800, res = 300)
par(mfrow=c(2,2))
temp <- ts(stdresC,start = 1981)
qqnorm(c(stdresC), col="blue",main = "",xlab="",ylab="")
qqline(c(stdresC),col="red")
acf(stdresC[14:1080],23,main="",xlab="",ylab="")
mtext("Diagnostic. Center Temperature", side = 3, line = -3, outer = TRUE)
temp <- ts(stdresLR,start = 1981)
qqnorm(c(stdresLR), col="blue",main = "",xlab="",ylab="")
qqline(c(stdresLR),col="red")
acf(stdresLR[14:1080],23,main="",xlab="",ylab="")
mtext("Diagnostic. Log-Range Temperature", side = 3, line = -19, outer = TRUE)
dev.off()

### FIGURES FOR PAPER ####

mse.c<-outC$P[1,1,26:1081]
levsup.c<-outC$a[26:1081,1]+1.96*sqrt(mse.c)
levinf.c<-outC$a[26:1081,1]-1.96*sqrt(mse.c)

mse.lr<-outLR$P[1,1,26:1081]
levsup.lr<-outLR$a[26:1081,1]+1.96*sqrt(mse.lr)
levinf.lr<-outLR$a[26:1081,1]-1.96*sqrt(mse.lr)

seas.c <- rowSums(outC$a[26:1081,3:13])
seas.LR <- rowSums(outLR$a[26:1081,3:13])

seas.c.var<-0
seas.lr.var<-0
for (j in 26:1081){
  seas.c.var[j-25] <- sum(diag((outC$P[3:13,3:13,j])))
  seas.lr.var[j-25] <- sum(diag((outLR$P[3:13,3:13,j])))
}

Seassup.c<-seas.c+1.96*sqrt(seas.c.var)
Seasinf.c<-seas.c-1.96*sqrt(seas.c.var)

Seassup.lr<-seas.LR+1.96*sqrt(seas.lr.var)
Seasinf.lr<-seas.LR-1.96*sqrt(seas.lr.var)
#### TYPE 2

par(mfrow=c(3,2))
conf.bandsC <- cbind(outC$a[26:1081,1], levinf.c,levsup.c)
tempC <- cbind(conf.bandsC)
tempC<- ts(tempC,start = 1932,frequency =12)
cols <- c("blue","red","red")
lwd <- c(2,1,1)
lty <- c(1,2,2)
plot.ts(tempC, plot.type="single", col = cols,lwd = lwd,
        lty=lty,xlab="",ylab="",main="",ylim=c(10,20))

conf.bandsLR <- cbind(outLR$a[26:1081,1], levinf.lr,levsup.lr)
tempLR <- cbind(conf.bandsLR)
tempLR<- ts(tempLR,start = 1932,frequency =12)
cols <- c("blue","red","red")
lwd <- c(2,1,1)
lty <- c(1,2,2)
plot.ts(tempLR, plot.type="single", col = cols,lwd = lwd,
        lty=lty,xlab="",ylab="",main="",ylim=c(1.9,2.7))


png("MadridC_FilteredLevel.png", width = 2400, height = 1800, res = 300)
plot.ts(tempC, plot.type = "single", col = cols, lwd = lwd,
        lty = lty, xlab = "Year", ylab = "Centre Temperature",
        main = "", ylim = c(10, 20), cex.lab = 1.5, cex.axis = 1.3)
dev.off()

# Figura 2: Log Range
png("MadridLR_FilteredLevel.png", width = 2400, height = 1800, res = 300)
plot.ts(tempLR, plot.type = "single", col = cols, lwd = lwd,
        lty = lty, xlab = "Year", ylab = "Log Range Temperature",
        main = "", ylim = c(1.9, 2.7), cex.lab = 1.5, cex.axis = 1.3)
dev.off()

conf.bandsC <- cbind(seas.c[576:1056])
tempC <- cbind(conf.bandsC)
tempC<- ts(tempC,start = 1980,frequency =12)
cols <- c("blue")
lwd <- c(3,1,1)
lty <- c(1,2,2)
plot.ts(tempC, plot.type="single", col = cols,lwd = lwd,
        lty=lty,xlab="",ylab="",main="",ylim=c(-15,15))

png("MadridC_Seasonal.png", width = 2400, height = 1800, res = 300)
plot.ts(tempC, plot.type = "single", col = cols, lwd = lwd,
        lty = lty, xlab = "Year", ylab = "Centre Temperature",
        main = "", ylim = c(-15, 15), cex.lab = 1.5, cex.axis = 1.3)
dev.off()

conf.bandsLR <- cbind(seas.LR[576:1056])
tempLR <- cbind(conf.bandsLR)
tempLR<- ts(tempLR,start = 1980,frequency =12)
cols <- c("blue")
lwd <- c(3,1,1)
lty <- c(1,2,2)
plot.ts(tempLR, plot.type="single", col = cols,lwd = lwd,
        lty=lty,xlab="",ylab="",main="",ylim=c(-0.4,0.4))

png("MadridLR_Seasonal.png", width = 2400, height = 1800, res = 300)
plot.ts(tempLR, plot.type = "single", col = cols, lwd = lwd,
        lty = lty, xlab = "Year", ylab = "Log Range Temperature",
        main = "", ylim = c(-0.4, 0.4), cex.lab = 1.5, cex.axis = 1.3)
dev.off()


tempC <- ts( c(outC$v[25:1080,1]),start = 1932,frequency =12)
plot(tempC, col = "blue",lwd = 2,xlab="",ylab="",main="",ylim=c(-4,4))
abline(h=0,col="grey")

tempLR <- ts( c(outLR$v[25:1080,1]),start = 1932,frequency =12)
plot(tempLR, col = "blue",lwd = 2,xlab="",ylab="",main="",ylim=c(-0.4,0.4))
abline(h=0,col="grey")

