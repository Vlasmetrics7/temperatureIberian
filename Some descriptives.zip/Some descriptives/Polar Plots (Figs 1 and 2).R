remove(list= ls())

library(readxl)
library(forecast)   # ggseasonplot()
library(ggplot2)
library(gridExtra)  # grid.arrange()
library(grid)       # textGrob(), gpar()
library(ggpubr)     # ggarrange(), annotate_figure(), text_grob()

dataMax <- read_excel("TempMaxSpain.xlsx",sheet = "data")
dataMin <- read_excel("TempMinSpain.xlsx",sheet = "data")

dataMax=ts(dataMax[349:1440,2:5],frequency=12,start=c(1930,1))
dataMin=ts(dataMin[349:1440,2:5],frequency=12,start=c(1930,1))

CentroTemp = (dataMax+dataMin)/2
colnames(CentroTemp) <- c("Madrid","Barcelona","Sevilla","A Coruna")

RankTemp = log(dataMax-dataMin)
colnames(RankTemp) <- c("Madrid","Barcelona","Sevilla","A Coruna")


## POLAR PLOTS FIGURES 1 AND 2

# Center Temperature

p1<-ggseasonplot(CentroTemp[,1], polar=TRUE, year.labels = FALSE,  continuous = TRUE,
                 labelgap = 0.01,ylim = c(-2,36),
                 season.labels= c("January","February","March","April",
                                  "May","June","July","August",
                                  "September","October",
                                  "November","December"))+
  ylab("") + xlab("")+
  scale_color_continuous(name= "Year") +
  ggtitle("Madrid")

p2<-ggseasonplot(CentroTemp[,2], polar=TRUE, year.labels = FALSE,  continuous = TRUE,
                 labelgap = 0.01,ylim = c(-2,36),
                 season.labels= c("January","February","March","April",
                                  "May","June","July","August",
                                  "September","October",
                                  "November","December"))+
  ylab("") + xlab("")+
  scale_color_continuous(name= "Year") +
  ggtitle("Barcelona")

p3<-ggseasonplot(CentroTemp[,3], polar=TRUE, year.labels = FALSE,  continuous = TRUE,
                 labelgap = 0.01,ylim = c(-2,36),
                 season.labels= c("January","February","March","April",
                                  "May","June","July","August",
                                  "September","October",
                                  "November","December"))+
  ylab("") + xlab("")+
  scale_color_continuous(name= "Year") +
  ggtitle("Sevilla")

p4<-ggseasonplot(CentroTemp[,4], polar=TRUE, year.labels = FALSE,  continuous = TRUE,
                 labelgap = 0.01,ylim = c(-2,36),
                 season.labels= c("January","February","March","April",
                                  "May","June","July","August",
                                  "September","October",
                                  "November","December"))+
  ylab("") + xlab("")+
  scale_color_continuous(name= "Year") +
  ggtitle("A Coruna")


label = textGrob("", rot = 90, vjust = 0.5)
grid.arrange(p1,p2,p3,p4,ncol = 2, nrow = 2,left=label)




season_labels <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun",
                   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

plot_fun <- function(series, city){
  ggseasonplot(series,
               polar = TRUE,
               year.labels = FALSE,
               continuous = TRUE,
               labelgap = 0.01,
               ylim = c(-2, 36),
               season.labels = season_labels) +
    xlab("") +
   # scale_color_gradient(
  #    name = "Year",
  #    low  = "grey85",
  #    high = "grey15",
  #    guide = guide_colorbar(barheight = unit(60, "pt"))
  #  ) +
    ggtitle(city) +
    theme_minimal(base_size = 16) +
    theme(
      axis.text.x   = element_text(size = 16),
      axis.text.y   = element_text(size = 12),
      legend.text   = element_text(size = 12),
      legend.title  = element_text(size = 14),
      plot.title    = element_text(size = 18, face = "bold", hjust = 0.5)
    )
}

p1 <- plot_fun(CentroTemp[,1], "Madrid")
p2 <- plot_fun(CentroTemp[,2], "Barcelona")
p3 <- plot_fun(CentroTemp[,3], "Sevilla")
p4 <- plot_fun(CentroTemp[,4], "A Coruña")

label = textGrob("", rot = 90, vjust = 0.5, gp=gpar(fontsize=12))
grid.arrange(p1, p2, p3, p4, ncol = 2, nrow = 2, left = label)

ggarrange(p1, p2, p3, p4,
          ncol = 2, nrow = 2,
          labels = NULL,
          align = "hv",
          common.legend = TRUE,
          legend = "right")

final_plot <- annotate_figure(
  ggarrange(p1, p2, p3, p4,
            ncol = 2, nrow = 2,
            align = "hv",
            common.legend = TRUE,
            legend = "right"),
  left = text_grob("Centre temperature", rot = 90, vjust = 1, size = 25)
)

# Save the figure
#ggsave("SeasonalPolarCentre.png", final_plot,
 #      width = 12, height = 10, dpi = 300, bg = "white")


# Range Temperature


p1<-ggseasonplot(RankTemp[,1], polar=TRUE, year.labels = FALSE,  continuous = TRUE,
                 labelgap = 0.01,ylim = c(1.2,3),
                 season.labels= c("January","February","March","April",
                                  "May","June","July","August",
                                  "September","October",
                                  "November","December"))+
  ylab("") + xlab("")+
  scale_color_continuous(name= "Year") +
  ggtitle("Madrid")

p2<-ggseasonplot(RankTemp[,2], polar=TRUE, year.labels = FALSE,  continuous = TRUE,
                 labelgap = 0.01,ylim = c(1.2,3),
                 season.labels= c("January","February","March","April",
                                  "May","June","July","August",
                                  "September","October",
                                  "November","December"))+
  ylab("") + xlab("")+
  scale_color_continuous(name= "Year") +
  ggtitle("Barcelona")

p3<-ggseasonplot(RankTemp[,3], polar=TRUE, year.labels = FALSE,  continuous = TRUE,
                 labelgap = 0.01,ylim = c(1.2,3),
                 season.labels= c("January","February","March","April",
                                  "May","June","July","August",
                                  "September","October",
                                  "November","December"))+
  ylab("") + xlab("")+
  scale_color_continuous(name= "Year") +
  ggtitle("Sevilla")

p4<-ggseasonplot(RankTemp[,4], polar=TRUE, year.labels = FALSE,  continuous = TRUE,
                 labelgap = 0.01,ylim = c(1.2,3),
                 season.labels= c("January","February","March","April",
                                  "May","June","July","August",
                                  "September","October",
                                  "November","December"))+
  ylab("") + xlab("")+
  scale_color_continuous(name= "Year") +
  ggtitle("A Coruna")


label = textGrob("", rot = 90, vjust = 0.5)
grid.arrange(p1,p2,p3,p4,ncol = 2, nrow = 2,left=label)


season_labels <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun",
                   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

plot_fun <- function(series, city){
  ggseasonplot(series,
               polar = TRUE,
               year.labels = FALSE,
               continuous = TRUE,
               labelgap = 0.01,
               ylim = c(1.2, 3),
               season.labels = season_labels) +
    xlab("") +
#    scale_color_gradient(
#      name = "Year",
#      low  = "grey85",
#      high = "grey15",
#      guide = guide_colorbar(barheight = unit(60, "pt"))
#    ) +
    ggtitle(city) +
    theme_minimal(base_size = 16) +
    theme(
      axis.text.x   = element_text(size = 16),
      axis.text.y   = element_text(size = 12),
      legend.text   = element_text(size = 12),
      legend.title  = element_text(size = 14),
      plot.title    = element_text(size = 18, face = "bold", hjust = 0.5)
    )
}


p1 <- plot_fun(RankTemp[,1], "Madrid")
p2 <- plot_fun(RankTemp[,2], "Barcelona")
p3 <- plot_fun(RankTemp[,3], "Sevilla")
p4 <- plot_fun(RankTemp[,4], "A Coruña")

label = textGrob("", rot = 90, vjust = 0.5, gp=gpar(fontsize=12))
grid.arrange(p1, p2, p3, p4, ncol = 2, nrow = 2, left = label)

ggarrange(p1, p2, p3, p4,
          ncol = 2, nrow = 2,
          labels = NULL,
          align = "hv",
          common.legend = TRUE,
          legend = "right")

final_plot <- annotate_figure(
  ggarrange(p1, p2, p3, p4,
            ncol = 2, nrow = 2,
            align = "hv",
            common.legend = TRUE,
            legend = "right"),
  left = text_grob("Log-range temperature", rot = 90, vjust = 1, size = 25)
)

# Save the figure
#ggsave("SeasonalPolarLogRange.png", final_plot,
 #      width = 12, height = 10, dpi = 300, bg = "white")