library(ggplot2)
library(patchwork)
library(dplyr)
library(readxl)

data = read_excel("CenterDes.xlsx",sheet = "data")
Avg_Temp <- rowMeans(data)

Max_Temp <- apply(data, 1, max) 
Min_Temp <- apply(data, 1, min) 
theoretical_logrange <- log(Max_Temp-Min_Temp) 
###

T <- length(Avg_Temp)
fecha <- seq(as.Date("1931-01-01"), by = "1 month", length.out = T)

# Expanding windows every 15 years = 180 months
cutoffs <- seq(180, T, by = 180)
colors <- scales::hue_pal()(length(cutoffs))  # distinct colors

# Estimate trends and organize into a tidy long data frame
trend_list_A <- list()
trend_list_R <- list()

for (i in seq_along(cutoffs)) {
  cutoff <- cutoffs[i]
  fecha_cut <- fecha[1:cutoff]
  label <- paste0("First ", cutoff / 12, " years")
  
  # Linear model for Avg_Temp
  model_A <- lm(Avg_Temp[1:cutoff] ~ fecha_cut)
  fit_A <- predict(model_A, newdata = data.frame(fecha_cut = fecha))
  
  # Linear model for theoretical range
  model_R <- lm(theoretical_logrange[1:cutoff] ~ fecha_cut)
  fit_R <- predict(model_R, newdata = data.frame(fecha_cut = fecha))
  
  # Store trends (solid and dashed)
  trend_list_A[[i]] <- data.frame(
    fecha = fecha,
    value = fit_A,
    label = label,
    type = ifelse(1:T <= cutoff, "Estimated", "Extrapolated")
  )
  
  trend_list_R[[i]] <- data.frame(
    fecha = fecha,
    value = fit_R,
    label = label,
    type = ifelse(1:T <= cutoff, "Estimated", "Extrapolated")
  )
}

trend_df_A <- bind_rows(trend_list_A)
trend_df_R <- bind_rows(trend_list_R)

# Base data frame for original series
df_plot <- data.frame(
  fecha = fecha,
  Avg_Temp = Avg_Temp,
  Theoretical_Range = theoretical_logrange
)

window_labels <- paste0("First ", cutoffs/12, " years")

grey_vals <- grDevices::gray(seq(0.80, 0, length.out = length(window_labels)))
names(grey_vals) <- window_labels


# --- Plot 1: Avg_Temp ---
p1 <- ggplot() +
  geom_line(data = df_plot, aes(x = fecha, y = Avg_Temp),
            color = "gray", linewidth = 0.4) +
  geom_line(data = trend_df_A,
            aes(x = fecha, y = value, color = label, linetype = type),
            linewidth = 1.25) +
  scale_color_manual(values = grey_vals, drop = FALSE) +
  scale_linetype_manual(values = c(Estimated = "solid", Extrapolated = "22")) +
  labs(y = "Average temperature", x = NULL,
       color = "Trend window", linetype = "Type") +
  scale_x_date(date_labels = "%Y", date_breaks = "10 years") +
  theme_minimal(base_size = 10) +
  theme(axis.text.x = element_blank(),
        legend.position = "bottom",
        legend.box = "vertical",
        legend.title = element_text(size = 10),
        legend.text  = element_text(size = 9))

# Add vertical regime cutoffs (do NOT touch legend here)
for (cutoff in cutoffs[-length(cutoffs)]) {
  p1 <- p1 + geom_vline(xintercept = fecha[cutoff],
                        linetype = "22", color = "black", linewidth = 0.35)
  p1 <- p1 + theme(legend.position = "none")
}

# --- Plot 2: Log-Range ---
p2 <- ggplot() +
  geom_line(data = df_plot, aes(x = fecha, y = Theoretical_Range),
            color = "gray", linewidth = 0.4) +
  geom_line(data = trend_df_R,
            aes(x = fecha, y = value, color = label, linetype = type),
            linewidth = 1.25) +
  scale_color_manual(values = grey_vals, drop = FALSE) +
  scale_linetype_manual(values = c(Estimated = "solid", Extrapolated = "22")) +
  labs(y = "Log-Range temperature", x = "Year",
       color = "Trend window", linetype = "Type") +
  scale_x_date(date_labels = "%Y", date_breaks = "10 years") +
  theme_minimal(base_size = 10) +
  theme(legend.position = "bottom",
        legend.box = "vertical",
        legend.title = element_text(size = 10),
        legend.text  = element_text(size = 9))

for (cutoff in cutoffs[-length(cutoffs)]) {
  p2 <- p2 + geom_vline(xintercept = fecha[cutoff],
                        linetype = "22", color = "black", linewidth = 0.35)
  p2 <- p2 + theme(legend.position = "none")
}

panel <- p1 / p2
print(panel)

# ggsave("expanding_window_panel.png", panel, width = 10, height = 8, dpi = 300)