# Utility functions
lag1 <- function(x) c(NA, x[-length(x)])

sanitize_matrix <- function(M, floor = 1e-8, ceiling = 1e+07) {
  M[is.na(M)]       <- floor
  M[is.infinite(M)] <- floor
  M[M <  floor]     <- floor
  M[M >  ceiling]   <- ceiling
  return(M)
}

clamp <- function(x, minval = 1e-6, maxval = 1e3) {
  pmax(pmin(x, maxval), minval)
}

# Data Generating Process
DGP_MLDFM <- function(T, Nr, stnr, stdreg, stdglob, R = 2) {
  Rf <- matrix(0, nrow = T, ncol = R)
  for (i in 1:R) {
    Rf[, i] <- arima.sim(n = T, list(ar = 0.25), sd = sqrt(stdreg))
  }
  Rf <- t(Rf)
  Gf <- cumsum(rnorm(T, mean = 0, sd = sqrt(stdglob)))
  u  <- matrix(rnorm(T * 2 * Nr, mean = 0, sd = sqrt(stnr)), nrow = T)
  
  lambda_r1 <- rnorm(Nr, mean = 1, sd = 1)
  lambda_r2 <- rnorm(Nr, mean = 1, sd = 1)
  gamma     <- rnorm(2 * Nr, mean = 1, sd = 1)
  
  lambda_matrix <- rbind(
    cbind(lambda_r1, rep(0, Nr)),
    cbind(rep(0, Nr), lambda_r2)
  )
  L_star <- cbind(gamma, lambda_matrix)
  F_star <- rbind(Gf, Rf)
  YSeries <- L_star %*% F_star + t(u)
  
  list(YSeries      = YSeries,
       LambdaMatrix = L_star,
       Gf           = Gf,
       Rf           = Rf,
       FactorMatrix = F_star,
       u            = u)
}

# Monte Carlo + EM Estimation
MC_MLDFM <- function(T, Nr, stnr, stdreg, stdglob, R = 2,
                     max_iter = 1000, tol = 1e-4) {
  res <- DGP_MLDFM(T, Nr, stnr, stdreg, stdglob, R)
  #Center <- scale(t(res$YSeries))
  Center <- t(res$YSeries)
  
  Z0      <- res$LambdaMatrix
  Zt      <- apply(Z0, 2, as.numeric)
  Zt_rest=Zt
  
  FactPCA <- t(res$FactorMatrix)
  a_init  <- c(FactPCA[1,1], FactPCA[1,2], FactPCA[1,3])
  
  Qt_vals<-(c(var(diff(FactPCA[,1])), apply(FactPCA[,2:(R+1)], 2, var)))
  Qt      <- diag(clamp(Qt_vals))
  
  Residuals0 <- Center - t(Z0 %*% t(FactPCA))
  Ht      <- diag(clamp(apply(Residuals0, 2, var)))
  
  phiR    <- 0.25
  
  Tt      <- diag(c(1,rep(phiR, R)))
  Rt      <- diag(1 + R)
  
  prev_ll <- NA
  failed  <- FALSE
  
  for (iter in 1:max_iter) {
    Qt     <- sanitize_matrix(Qt)
    Ht     <- sanitize_matrix(Ht)
    Tt     <- sanitize_matrix(Tt)
    a_init <- sanitize_matrix(matrix(a_init, ncol = 1))[,1]
    
    out <- tryCatch({
      model <- SSModel(Center ~ -1 +
                         SSMcustom(Z = Zt, T = Tt, R = Rt,
                                   Q = Qt, a1 = a_init, P1 = Qt),
                       H = Ht)
      filt  <- KFS(model, filtering = c("state","signal"),
                   smoothing = c("state","disturbance"))
      list(ok = TRUE, f = filt)
    }, error = function(e) {
      list(ok = FALSE)
    })
    
    if (!out$ok) { failed <- TRUE; break }
    filt <- out$f
    
    last_index <- length(filt$Ptt)
    if (last_index < T) warning("Ptt has fewer entries than T")
    P_trace <- sum(diag(filt$Ptt[[last_index]]))
    if (P_trace > 1e6) { failed <- TRUE; break }
    
    load_upd <- t(Center) %*% filt$alphahat %*%
      solve(t(filt$alphahat) %*% filt$alphahat)
    Zt       <- load_upd
    Zt[Zt_rest == 0] <- 0
    
    eps_var <- apply(filt$epshat, 2, var)
    Ht      <- diag(clamp(eps_var))
    
    ll <- filt$logLik
    if (!is.na(prev_ll) && !is.na(ll) &&
        abs((ll - prev_ll) / ((abs(ll) + abs(prev_ll)) / 2 + 1e-16)) < tol) break
    prev_ll <- ll
  }
  
  if (failed) return(c(NA, NA, NA))
  
  burn <- ceiling(T * 0.1)
  Alph <- filt$alphahat[(burn+1):T, ]
  
  AFm <- apply(Alph, 2, mean)
  AFs <- apply(Alph, 2, sd)
  SF  <- sweep(Alph, 2, AFm)
  SF  <- sweep(SF,   2, AFs, FUN = "/")
  
  FG <- res$Gf[(burn+1):T]
  R1 <- res$Rf[1, (burn+1):T]
  R2 <- res$Rf[2, (burn+1):T]
  
  R2G  <- summary(lm(scale(FG) ~ SF[,1] ))$r.squared
  R2R1 <- summary(lm(scale(R1) ~ SF[,2] ))$r.squared
  R2R2 <- summary(lm(scale(R2) ~ SF[,3] ))$r.squared
  
  c(R2G, R2R1, R2R2)
}

# INDIVIDUALES 

for (i in 1:100) {
  print(i)
  # print("Contruyendo Tabla 1")
  ResultsMC1[i,] <- MC_MLDFM(T = 150, Nr = 40,stnr = 2*0.5, stdreg = 4,stdglob = 1, R = 2)
   ResultsMC2[i,] = MC_MLDFM(T = 150, Nr = 40, stnr = 2*0.5, stdreg = 1, stdglob = 1,R=2)
   ResultsMC3[i,] = MC_MLDFM(T = 150, Nr = 40, stnr = 2*0.5, stdreg = 1, stdglob = 4,R=2)
   ResultsMC4[i,] = MC_MLDFM(T = 150, Nr = 40, stnr = 2*2, stdreg = 4, stdglob = 1,R=2)
   ResultsMC5[i,] = MC_MLDFM(T = 150, Nr = 40, stnr = 2*2, stdreg = 1, stdglob = 1,R=2)
   ResultsMC6[i,] = MC_MLDFM(T = 150, Nr = 40, stnr = 2*2, stdreg = 1, stdglob = 4,R=2)
   ResultsMC7[i,] = MC_MLDFM(T = 150, Nr = 40, stnr = 2*5, stdreg = 4, stdglob = 1,R=2)
   ResultsMC8[i,] = MC_MLDFM(T = 150, Nr = 40, stnr = 2*5, stdreg = 1, stdglob = 1,R=2)
   ResultsMC9[i,] = MC_MLDFM(T = 150, Nr = 40, stnr = 2*5, stdreg = 1, stdglob = 4,R=2)
  #   print("Contruyendo Tabla 2")
  # ResultsMC10[i,] <- MC_MLDFM(T = 150, Nr = 500,stnr = 2*0.5, stdreg = 4,stdglob = 1, R = 2)
  # ResultsMC11[i,] = MC_MLDFM(T = 150, Nr = 500, stnr = 2*0.5, stdreg = 1, stdglob = 1,R=2)
  # ResultsMC12[i,] = MC_MLDFM(T = 150, Nr = 500, stnr = 2*0.5, stdreg = 1, stdglob = 4,R=2)
  # ResultsMC13[i,] = MC_MLDFM(T = 150, Nr = 500, stnr = 2*2, stdreg = 4, stdglob = 1,R=2)
  # ResultsMC14[i,] = MC_MLDFM(T = 150, Nr = 500, stnr = 2*2, stdreg = 1, stdglob = 1,R=2)
  # ResultsMC15[i,] = MC_MLDFM(T = 150, Nr = 500, stnr = 2*2, stdreg = 1, stdglob = 4,R=2)
  # ResultsMC16[i,] = MC_MLDFM(T = 150, Nr = 500, stnr = 2*5, stdreg = 4, stdglob = 1,R=2)
  # ResultsMC17[i,] = MC_MLDFM(T = 150, Nr = 500, stnr = 2*5, stdreg = 1, stdglob = 1,R=2)
  # ResultsMC18[i,] = MC_MLDFM(T = 150, Nr = 500, stnr = 2*5, stdreg = 1, stdglob = 4,R=2)
  #   print("Contruyendo Tabla 3")
  #   ResultsMC19[i,] <- MC_MLDFM(T = 500, Nr = 40,stnr = 2*0.5, stdreg = 4,stdglob = 1, R = 2)
  #   ResultsMC20[i,] = MC_MLDFM(T = 500, Nr = 40, stnr = 2*0.5, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC21[i,] = MC_MLDFM(T = 500, Nr = 40, stnr = 2*0.5, stdreg = 1, stdglob = 4,R=2)
  #   ResultsMC22[i,] = MC_MLDFM(T = 500, Nr = 40, stnr = 2*2, stdreg = 4, stdglob = 1,R=2)
  #   ResultsMC23[i,] = MC_MLDFM(T = 500, Nr = 40, stnr = 2*2, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC24[i,] = MC_MLDFM(T = 500, Nr = 40, stnr = 2*2, stdreg = 1, stdglob = 4,R=2)
  #   ResultsMC25[i,] = MC_MLDFM(T = 500, Nr = 40, stnr = 2*5, stdreg = 4, stdglob = 1,R=2)
  #   ResultsMC26[i,] = MC_MLDFM(T = 500, Nr = 40, stnr = 2*5, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC27[i,] = MC_MLDFM(T = 500, Nr = 40, stnr = 2*5, stdreg = 1, stdglob = 4,R=2)
  #   print("Contruyendo Tabla 4")
  #   ResultsMC28[i,] <- MC_MLDFM(T = 500, Nr = 100,stnr = 2*0.5, stdreg = 4,stdglob = 1, R = 2)
  #   ResultsMC29[i,] = MC_MLDFM(T = 500, Nr = 100, stnr = 2*0.5, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC30[i,] = MC_MLDFM(T = 500, Nr = 100, stnr = 2*0.5, stdreg = 1, stdglob = 4,R=2)
  #   ResultsMC31[i,] = MC_MLDFM(T = 500, Nr = 100, stnr = 2*2, stdreg = 4, stdglob = 1,R=2)
  #   ResultsMC32[i,] = MC_MLDFM(T = 500, Nr = 100, stnr = 2*2, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC33[i,] = MC_MLDFM(T = 500, Nr = 100, stnr = 2*2, stdreg = 1, stdglob = 4,R=2)
  #   ResultsMC34[i,] = MC_MLDFM(T = 500, Nr = 100, stnr = 2*5, stdreg = 4, stdglob = 1,R=2)
  #   ResultsMC35[i,] = MC_MLDFM(T = 500, Nr = 100, stnr = 2*5, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC36[i,] = MC_MLDFM(T = 500, Nr = 100, stnr = 2*5, stdreg = 1, stdglob = 4,R=2)
  #   print("Contruyendo Tabla 5")
  #   ResultsMC37[i,] <- MC_MLDFM(T = 1000, Nr = 40,stnr = 2*0.5, stdreg = 4,stdglob = 1, R = 2)
  #   ResultsMC38[i,] = MC_MLDFM(T = 1000, Nr = 40, stnr = 2*0.5, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC39[i,] = MC_MLDFM(T = 1000, Nr = 40, stnr = 2*0.5, stdreg = 1, stdglob = 4,R=2)
  #   ResultsMC40[i,] = MC_MLDFM(T = 1000, Nr = 40, stnr = 2*2, stdreg = 4, stdglob = 1,R=2)
  #   ResultsMC41[i,] = MC_MLDFM(T = 1000, Nr = 40, stnr = 2*2, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC42[i,] = MC_MLDFM(T = 1000, Nr = 40, stnr = 2*2, stdreg = 1, stdglob = 4,R=2)
  #   ResultsMC43[i,] = MC_MLDFM(T = 1000, Nr = 40, stnr = 2*5, stdreg = 4, stdglob = 1,R=2)
  #   ResultsMC44[i,] = MC_MLDFM(T = 1000, Nr = 40, stnr = 2*5, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC45[i,] = MC_MLDFM(T = 1000, Nr = 40, stnr = 2*5, stdreg = 1, stdglob = 4,R=2)
  #   print("Contruyendo Tabla 6")
  #   ResultsMC46[i,] <- MC_MLDFM(T = 1000, Nr = 100,stnr = 2*0.5, stdreg = 4,stdglob = 1, R = 2)
  #   ResultsMC47[i,] = MC_MLDFM(T = 1000, Nr = 100, stnr = 2*0.5, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC48[i,] = MC_MLDFM(T = 1000, Nr = 100, stnr = 2*0.5, stdreg = 1, stdglob = 4,R=2)
  #   ResultsMC49[i,] = MC_MLDFM(T = 1000, Nr = 100, stnr = 2*2, stdreg = 4, stdglob = 1,R=2)
  #   ResultsMC50[i,] = MC_MLDFM(T = 1000, Nr = 100, stnr = 2*2, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC51[i,] = MC_MLDFM(T = 1000, Nr = 100, stnr = 2*2, stdreg = 1, stdglob = 4,R=2)
  #   ResultsMC52[i,] = MC_MLDFM(T = 1000, Nr = 100, stnr = 2*5, stdreg = 4, stdglob = 1,R=2)
  #   ResultsMC53[i,] = MC_MLDFM(T = 1000, Nr = 100, stnr = 2*5, stdreg = 1, stdglob = 1,R=2)
  #   ResultsMC54[i,] = MC_MLDFM(T = 1000, Nr = 100, stnr = 2*5, stdreg = 1, stdglob = 4,R=2)
}

##############



library(foreach)
library(doParallel)
library(progressr)
library(doSNOW)


#handlers(global = TRUE)

num_cores <- detectCores() - 1
cl <- makeCluster(num_cores)
registerDoSNOW(cl)

handlers("txtprogressbar")  # or "progress"

designs <- expand.grid(
  T = c(150, 250, 500),
  Nr = c(40, 100),
  stnr = c(0.5, 1, 2.5),
  stdreg = c(1, 2),
  stdglob = c(1, 2),
  R = 2
)

designs <- subset(designs,
                  (stnr == 0.5 & stdreg == 1 & stdglob == 2) |
                    (stnr == 0.5 & stdreg == 1 & stdglob == 1) |
                    (stnr == 0.5 & stdreg == 2 & stdglob == 1) |
                    (stnr == 1 & stdreg == 1 & stdglob == 2) |
                    (stnr == 1 & stdreg == 1 & stdglob == 1) |
                    (stnr == 1 & stdreg == 2 & stdglob == 1) |
                    (stnr == 2.5 & stdreg == 1 & stdglob == 2) |
                    (stnr == 2.5 & stdreg == 1 & stdglob == 1) |
                    (stnr == 2.5 & stdreg == 2 & stdglob == 1)
)
designs$scenario <- 1:nrow(designs)

nreps <- 1000
nsteps <- nreps

pb <- txtProgressBar(max = nreps, style = 3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress = progress)

ResultsAll <- foreach(i = 1:nreps, .combine = rbind,
                      .options.snow = opts,
                      .packages = "KFAS") %dopar% {
                        out <- lapply(1:nrow(designs), function(j) {
                          d <- designs[j, ]
                          res <- tryCatch({
                            MC_MLDFM(T = d$T, Nr = d$Nr, stnr = d$stnr,
                                     stdreg = d$stdreg, stdglob = d$stdglob, R = d$R)
                          }, error = function(e) c(NA, NA, NA))
                          c(replication = i, scenario = d$scenario, res)
                        })
                        do.call(rbind, out)
                      }

stopCluster(cl)

ResultsDF <- as.data.frame(ResultsAll)
colnames(ResultsDF) <- c("Replication", "Scenario", "R2_Glob", "R2_Reg1", "R2_Reg2")

ResultsSummary <- aggregate(. ~ Scenario, data = ResultsDF[, -1], FUN = mean)

print(ResultsSummary)










