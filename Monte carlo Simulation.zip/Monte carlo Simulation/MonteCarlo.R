# Integrated Random Walk Function
IRW_sim <- function(T, sigma_xi) {
  xi <- rnorm(T, mean = 0, sd = sqrt(sigma_xi))
  beta <- numeric(T)
  Fg <- numeric(T)
  
  beta[1] <- 0
  Fg[1] <- 0
  
  for (t in 2:T) {
    beta[t] <- beta[t - 1] + xi[t]
    Fg[t] <- Fg[t - 1] + beta[t - 1]
  }
  
  return(Fg)
}

DGP_MLDFM <- function(T, Nr, stnr, stdreg, stdglob,R) {
#  R <- 2
  Rf <- matrix(0, nrow = T, ncol = R)
  
  for (i in 1:R) {
    R1 <- arima.sim(n = T, list(ar = 0.75), sd = sqrt(stdreg))
    Rf[, i] <- R1
  }
  Rf <- t(Rf)  
  
  Gf <- IRW_sim(T, sqrt(stdglob)) 
  
  u <- matrix(0, nrow = T, ncol = 2 * Nr)
  for (i in 1:(2 * Nr)) {
    #R2 <- arima.sim(n = T, list(ar = 0.5), sd = sqrt(stnr))
    u[, i] <- rnorm(T, mean = 0, sd = sqrt(stnr))
  }                                                   
  
  lambda_r1 <- rnorm(Nr, mean = 1, sd = 1)  
  lambda_r2 <- rnorm(Nr, mean = 1, sd = 1)
  gamma <- rnorm(2 * Nr, mean = 1, sd = 1)
  
  # Create L_star matrix
  lambda_matrix <- rbind(
    cbind(lambda_r1, rep(0, Nr)),
    cbind(rep(0, Nr), lambda_r2)
  )
  L_star <- cbind(gamma, lambda_matrix)     
  
  F_star <- rbind(Gf, Rf)  
  U_star <- t(u) 
  
  YSeries <- L_star %*% F_star + U_star
  
   return(list(
    YSeries = YSeries,
    gamma = gamma,
    lambda_r1 = lambda_r1,
    lambda_r2 = lambda_r2,
    LambdaMatrix =L_star,
    Gf = Gf,
    Rf = Rf,
    FactorMatrix=F_star,
    u = u
  ))
}

MC_MLDFM <- function(T,Nr,stnr,stdreg,stdglob,R) {

result = DGP_MLDFM(T, Nr, stnr, stdreg, stdglob,R)
Center<-t(result$YSeries)
Center=scale(Center)

Zt_orig= result$LambdaMatrix
Zt_aux=0*Zt_orig[,1]
Zt=cbind(Zt_orig[,1],Zt_aux,Zt_orig[,2:(R+1)])
Zt=apply(Zt,2,as.numeric)
Zt_rest=Zt

FactPCA= t(result$FactorMatrix)
#a_init=c(mean(FactPCA[,1]),0,apply(FactPCA[,2:(R+1)],2,mean))
a_init=c(FactPCA[1,1],0,FactPCA[1,2],FactPCA[1,3])

Qt=diag(c(0, var(diff(diff(FactPCA[,1]))), apply(FactPCA[,2:(R+1)], 2, var)))
#Qt=diag(c(0,stdglob,stdreg,stdreg))

phiR1=0.75
phiR2=0.75
#phiR3=0.5
#phiR4=0.5

Tt=diag(c(1,1,phiR1,phiR2))
#Tt=diag(c(1,1,phiR1,phiR2,phiR3,phiR4,phiR5))
Tt[1,2]=1
Rt <- diag(4)

Residuals<-Center-t(data.matrix(Zt_orig)%*%t(data.matrix(FactPCA)))
Ht<-diag(apply(Residuals,2,var))

max_iter <- 1500
tolerance <- 1e-3
prev_loglik <- -100000

match_zeros <- function(A, B) {
  for (i in 1:nrow(A)) {
    for (j in 1:ncol(A)) {
      if (A[i, j] == 0) {
        B[i, j] <- 0
      }
    }
  }
  return(B)
}
print(Tt)
print(Rt)
print(Qt)
print(a_init)

for (iter in 1:max_iter) {
  if (iter == max_iter) warning("EM did not converge")
  
     model <- SSModel(Center ~-1+SSMcustom(Z = Zt, T = Tt, R = Rt, Q = Qt, a1=a_init,P1=Qt), H = Ht) 
              
  filtered <- KFS(model,filtering=c('state','signal'), smoothing=c('state','disturbance','mean'))
  
  #Tt=diag(c(1,1,0.75,0.75))
  #Tt[1,2]=1
  
  loading_update <-t(Center) %*% filtered$alphahat %*% solve(t(filtered$alphahat) %*% filtered$alphahat)
  
  Zt<-t(match_zeros(t(Zt_rest), t(loading_update)))
  Zt=apply(Zt,2,as.numeric)
  
  Ht<-diag(apply(filtered$epshat,2,var))

  loglik <- filtered$logLik
  
  delta_loglik <- abs(loglik - prev_loglik)
  avg_loglik = (abs(loglik) + abs(prev_loglik) + 2.2204e-16)/2
  if ((delta_loglik/avg_loglik) < tolerance){ break }

  prev_loglik <- loglik
}

### ESCALAMIENTO FACTORES ###

FactorsMean <- matrix(0,4,1)
FactorsSd <- matrix(0,4,1)
ScaledFactors <- matrix(0,T,4)
LoadingFactors<- matrix(0,Nr*R,4)

for (i in 1:4) {
  FactorsMean[i] <- mean(filtered$alphahat[,i])
  FactorsSd[i] <- sd(filtered$alphahat[,i])
  ScaledFactors[,i] <- (filtered$alphahat[,i] - FactorsMean[i]) / FactorsSd[i]
  LoadingFactors[,i]<- (Zt[,i]*FactorsSd[i])+FactorsMean[i] 
}
burn_in <- T*0.10
ScaledFactors <- ScaledFactors[(burn_in + 1):T, ]
#ScaledFactors <- ScaledFactors[13:T,]
ScaledLoading <-match_zeros(Zt_rest, LoadingFactors)

FacGlobOrig=result$Gf[(burn_in + 1):T]
FacReg1Orig=result$Rf[1,(burn_in + 1):T]
FacReg2Orig=result$Rf[2,(burn_in + 1):T]

RegG<- lm(scale(FacGlobOrig)~ScaledFactors[,1]+0)
RegR1<- lm(scale(FacReg1Orig)~ScaledFactors[,3]+0)
RegR2<- lm(scale(FacReg2Orig)~ScaledFactors[,4]+0)

R2Glob<-summary(RegG)$r.squared
R2Reg1<-summary(RegR1)$r.squared
R2Reg2<-summary(RegR2)$r.squared

return(cbind(R2Glob,R2Reg1,R2Reg2))
}

ResultsMC1<-matrix(0,100,3)
ResultsMC2<-matrix(0,100,3)
ResultsMC3<-matrix(0,100,3)
ResultsMC4<-matrix(0,100,3)
ResultsMC5<-matrix(0,100,3)
ResultsMC6<-matrix(0,100,3)
ResultsMC7<-matrix(0,100,3)
ResultsMC8<-matrix(0,100,3)
ResultsMC9<-matrix(0,100,3)

for (i in 1:100) {
  print(i)
   ResultsMC1[i,] = MC_MLDFM(T = 150, Nr = 20, stnr = 2*0.5, stdreg = 1, stdglob = 1,R=2)
   ResultsMC2[i,] = MC_MLDFM(T = 150, Nr = 20, stnr = 2*0.5, stdreg = 1, stdglob = 1,R=2)
   ResultsMC3[i,] = MC_MLDFM(T = 150, Nr = 20, stnr = 2*0.5, stdreg = 1, stdglob = 4,R=2)
   ResultsMC4[i,] = MC_MLDFM(T = 150, Nr = 20, stnr = 2*2, stdreg = 4, stdglob = 1,R=2)
   ResultsMC5[i,] = MC_MLDFM(T = 150, Nr = 20, stnr = 2*2, stdreg = 1, stdglob = 1,R=2)
  ResultsMC6[i,] = MC_MLDFM(T = 150, Nr = 20, stnr = 2*2, stdreg = 1, stdglob = 4,R=2)
   ResultsMC7[i,] = MC_MLDFM(T = 150, Nr = 20, stnr = 2*5, stdreg = 4, stdglob = 1,R=2)
   ResultsMC8[i,] = MC_MLDFM(T = 150, Nr = 20, stnr = 2*5, stdreg = 1, stdglob = 1,R=2)
   ResultsMC9[i,] = MC_MLDFM(T = 150, Nr = 20, stnr = 2*5, stdreg = 1, stdglob = 4,R=2)
}

rbind(colMeans(ResultsMC1),colMeans(ResultsMC2),
      colMeans(ResultsMC3),colMeans(ResultsMC4),
      colMeans(ResultsMC5),colMeans(ResultsMC6),
      colMeans(ResultsMC7),colMeans(ResultsMC8),
      colMeans(ResultsMC9))

boxplot(
  list(Global = ResultsMC1[,1],
       Region1 = ResultsMC1[,2],
       Region2 = ResultsMC1[,3]),
  main = "R² Distribution under Stronger Signal-to-Noise",
  col = c("steelblue", "tomato", "seagreen"),
  ylim = c(0,1)
)
